/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task.pkginterface.gráfica;

import javax.swing.JOptionPane;

/**
 *
 * @author biten
 */
public class TaskInterfaceGráfica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nome = JOptionPane.showInputDialog("Digite o nome do usuário:");
        String cpf = JOptionPane.showInputDialog("Digite o CPF do usuário:");
        JOptionPane.showMessageDialog(null, "Nome: " + nome + "\nCPF: " + cpf);
        

    }
    
}

package dadosacidentes;

import javax.swing.*;
import java.awt.*;
import java.text.DecimalFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class TelaPrincipal extends JFrame {
    private JLabel labelDataHora;
    private JLabel labelMortes;
    private JLabel labelAcidentes;

    private final double mortesPorMinuto = 0.0117;
    private final double acidentesPorMinuto = 0.0035;
    private final LocalDateTime inicioDoAno = LocalDateTime.of(2025, 1, 1, 0, 0);

    public TelaPrincipal() {
        setTitle("Acidentes em Tempo Real - São Paulo");
        setSize(450, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        setLayout(new GridLayout(4, 1));

        Font fonteGrande = new Font("Arial", Font.BOLD, 18); // ou qualquer outro tamanho desejado

labelDataHora = new JLabel("Data e hora atual:", JLabel.CENTER);
labelDataHora.setFont(fonteGrande);

labelMortes = new JLabel("Estimativa de mortes: ", JLabel.CENTER);
labelMortes.setFont(fonteGrande);

labelAcidentes = new JLabel("Estimativa de acidentes (uso do celular): ", JLabel.CENTER);
labelAcidentes.setFont(fonteGrande);


        add(labelDataHora);
        add(labelMortes);
        add(labelAcidentes);

        iniciarAtualizacao();
    }

    private void iniciarAtualizacao() {
        Timer timer = new Timer(1000, e -> atualizarDados());
        timer.start();
    }

    private void atualizarDados() {
        LocalDateTime agora = LocalDateTime.now();
        long minutosDesdeInicio = Duration.between(inicioDoAno, agora).toMinutes();

        double mortes = minutosDesdeInicio * mortesPorMinuto;
        double acidentes = minutosDesdeInicio * acidentesPorMinuto;

        DecimalFormat df = new DecimalFormat("#,###");

        labelDataHora.setText("Data e hora atual: " + agora.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")));
        labelMortes.setText("Estimativa de mortes até agora: " + df.format(mortes));
        labelAcidentes.setText("Estimativa de acidentes até agora: " + df.format(acidentes));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaPrincipal tela = new TelaPrincipal();
            tela.setVisible(true);
        });
    }
}

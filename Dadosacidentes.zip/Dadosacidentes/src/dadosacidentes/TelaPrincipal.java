import javax.swing.*;
import java.awt.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TelaPrincipal extends JFrame {

    private JLabel labelTitulo, labelDataHora, labelMortes, labelAcidentes;
    private final LocalDateTime inicioDoAno = LocalDateTime.of(2025, 1, 1, 0, 0);

    // Novas taxas: 17 mortes/dia e 233 acidentes/dia
    private final double mortesPorSegundo = 17.0 / 86400.0;
    private final double acidentesPorSegundo = 233.0 / 86400.0;

    public TelaPrincipal() {
        setTitle("Acidentrômetro SP");
        setSize(1000, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Cores inspiradas no dashboard moderno
        Color fundoDashboard = new Color(232, 240, 242); // cinza claro azulado
        Color corAcidente = new Color(0, 184, 148); // verde esmeralda
        Color corTexto = new Color(45, 52, 54); // texto quase preto
        Color corMortes = new Color(99, 110, 114); // cinza escuro

        getContentPane().setBackground(fundoDashboard);

        // Título
        labelTitulo = new JLabel("📊 Acidentrômetro SP", JLabel.CENTER);
        labelTitulo.setFont(new Font("Arial Black", Font.BOLD, 52));
        labelTitulo.setForeground(corTexto);
        labelTitulo.setBorder(BorderFactory.createEmptyBorder(30, 10, 20, 10));

        // Painel central com 3 cards
        JPanel painelCentral = new JPanel(new GridLayout(3, 1, 20, 20));
        painelCentral.setBorder(BorderFactory.createEmptyBorder(20, 80, 20, 80));
        painelCentral.setBackground(fundoDashboard);

        // Card: Data e hora
        labelDataHora = new JLabel("Data e hora atual:", JLabel.CENTER);
        labelDataHora.setFont(new Font("Verdana", Font.PLAIN, 30));
        labelDataHora.setForeground(corTexto);
        labelDataHora.setOpaque(true);
        labelDataHora.setBackground(Color.WHITE);
        labelDataHora.setBorder(BorderFactory.createLineBorder(corTexto, 2));
        labelDataHora.setPreferredSize(new Dimension(900, 60));

        // Card: Acidentes (destacado)
        labelAcidentes = new JLabel("Estimativa de acidentes: ", JLabel.CENTER);
        labelAcidentes.setFont(new Font("Verdana", Font.BOLD, 60));
        labelAcidentes.setForeground(corAcidente);
        labelAcidentes.setOpaque(true);
        labelAcidentes.setBackground(Color.WHITE);
        labelAcidentes.setBorder(BorderFactory.createLineBorder(corAcidente, 4));

        // Card: Mortes (menos destaque)
        labelMortes = new JLabel("Estimativa de mortes: ", JLabel.CENTER);
        labelMortes.setFont(new Font("Verdana", Font.PLAIN, 32));
        labelMortes.setForeground(corMortes);
        labelMortes.setOpaque(true);
        labelMortes.setBackground(Color.WHITE);
        labelMortes.setBorder(BorderFactory.createLineBorder(corMortes, 2));

        // Adiciona os cards ao painel
        painelCentral.add(labelDataHora);
        painelCentral.add(labelAcidentes);
        painelCentral.add(labelMortes);

        // Adiciona tudo ao frame
        add(labelTitulo, BorderLayout.NORTH);
        add(painelCentral, BorderLayout.CENTER);

        iniciarAtualizacao();
    }

    private void iniciarAtualizacao() {
        Timer timer = new Timer(1000, e -> atualizarDados()); // Atualiza a cada segundo
        timer.start();
    }

    private void atualizarDados() {
        LocalDateTime agora = LocalDateTime.now();
        long segundosDesdeInicio = Duration.between(inicioDoAno, agora).getSeconds();

        double mortes = segundosDesdeInicio * mortesPorSegundo;
        double acidentes = segundosDesdeInicio * acidentesPorSegundo;

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        labelDataHora.setText("🕒 " + agora.format(formatter));
        labelMortes.setText(String.format("☠ Mortes estimadas: %.0f", mortes));
        labelAcidentes.setText(String.format("🚗 Acidentes estimados: %.0f", acidentes));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TelaPrincipal().setVisible(true));
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task.escolha;

import javax.swing.JOptionPane;

/**
 *
 * @author biten
 */
public class TaskEscolha {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String opcao = JOptionPane.showInputDialog(
            "Escolha uma opção:\n1 - Saudação\n2 - Informações\n3 - Sair");

        if (opcao.equals("1")) {
            JOptionPane.showMessageDialog(null, "Olá! Bem-vindo ao sistema!");
        } else if (opcao.equals("2")) {
            JOptionPane.showMessageDialog(null, "Informações do sistema: Exemplo com JOptionPane");
        } else if (opcao.equals("3")) {
            JOptionPane.showMessageDialog(null, "Saindo...");
        } else {
            JOptionPane.showMessageDialog(null, "Opção inválida!");
    }
    
}
}
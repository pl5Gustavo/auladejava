//window.alert("você ganhou um prêmio");
//window.confirm("Deseja acessar seu prêmio");
window.prompt("Insira seu nome");

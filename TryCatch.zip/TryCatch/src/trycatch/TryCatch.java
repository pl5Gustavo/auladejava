/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trycatch;

import javax.swing.JOptionPane;

/**
 *
 * @author gustavo.blopes2
 */
public class TryCatch {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String idadeTexto = JOptionPane.showInputDialog("Digite sua idade (apenas números):"); 
           try {
 
            int idade = Integer.parseInt(idadeTexto); 
            JOptionPane.showMessageDialog(null, "Sua idade é: " + idade + " anos."); 
        } 
             catch (NumberFormatException e) { 
            JOptionPane.showMessageDialog(null, 
                    "Erro de Formato: Por favor, digite apenas números inteiros válidos para a idade.", 
                    "Erro de Entrada", JOptionPane.ERROR_MESSAGE); 
        }
 
        System.out.println("Processo de idade finalizado.");
                
                }
        }
       // int valor = 5;
       // int valor2 = 0;
        
        ///try{
         //   int resultado=valor/valor2;
           // System.out.println("o resultado é " + resultado);
        //}
       // catch(ArithmeticException e){
            
          //  System.out.println("divisão por zero");
       // }
        
      //  int valor = 5;
      // String valor2 = "10";
      // int valor3 = 0;
      // int[]lista ={50,80,90};
      // System.out.println(lista[3]);
      // System.out.println(valor/valor3);
    
    

